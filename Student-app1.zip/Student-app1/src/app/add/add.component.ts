import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  addForm:FormGroup;
  url:string="http://localhost:9090/students";
  constructor(private http:HttpClient,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.addForm=this.formBuilder.group({
      rollNumber:[''],
      studentName:[''],
      studentScore:['']
    });
  }
  addStudent():void{
    alert('add Studnet');
    this.http.post(this.url,this.addForm.value).subscribe(data=>{
      alert('student is added');
    });
  }

}
