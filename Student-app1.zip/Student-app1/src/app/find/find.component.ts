import { Component, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-find',
  templateUrl: './find.component.html',
  styleUrls: ['./find.component.css']
})
export class FindComponent implements OnInit {
  url:string="http://localhost:9090/students";
 rollNumber:number;
 result:any;
  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  findStudent():void{
    let url= this.url +"/"+ this.rollNumber;
    alert(this.url);
    this.http.get(url).subscribe(data=>{
      this.result=data;
    });
    
  }

}
