import { Component, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  url:string="http://localhost:9090/students";
  rollNumber:string;
  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  deleteStudent():void{
    let url= this.url +"/"+ this.rollNumber;
    alert(this.url);
    this.http.delete(url).subscribe(data=>{
    this.rollNumber='';
    alert('Student with roll number'+this.rollNumber+'delete');
  });
}

}
