package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Student;
@Repository
public class StudentDaoImpl implements StudentDao {
	@PersistenceContext
	private EntityManager entityManager;
	public StudentDaoImpl(){
		
	}
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int createStudent(Student student) {
		entityManager.persist(student);
		
		return 1;
	}
	@Override
	public Student readStudentByRollNumber(int rollNumber) {
		return entityManager.find(Student.class, rollNumber);
	}
	@Override
	public List<Student> readAllStudents() {
		String jpql = "From Student";
		TypedQuery<Student> tquery = entityManager.createQuery(jpql, Student.class);
		return tquery.getResultList();
	}
	@Transactional
	@Override
	public int deleteStudent(int rollNumber) {
		String jqpl="Delete From Student Where rollNumber=:rollno";
		Query query=entityManager.createQuery(jqpl);
		query.setParameter("rollno",rollNumber);
		return query.executeUpdate();
	}

	
	
}
